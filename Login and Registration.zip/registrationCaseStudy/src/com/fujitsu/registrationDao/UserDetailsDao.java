package com.fujitsu.registrationDao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.fujitsu.loginAndRegistration.module.User;
import com.mysql.cj.xdevapi.Statement;


public class UserDetailsDao {
	
	public ResultSet userDetails() {
	
	String url ="jdbc:mysql://localhost:3306/test";
	String db_username="root";
	String db_password="Nisha@123";
    Connection con;
	PreparedStatement pstmt;

	String sql="select * from user";
	
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection(url,db_username,db_password);
		pstmt=con.prepareStatement(sql);
		
		ResultSet rs=pstmt.executeQuery();
		System.out.println(rs);
		return rs;
		
		
	}catch(Exception e) {
		e.printStackTrace();
	}
	
	return null;
	
	
}

}
