package com.fujitsu.registrationDao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.fujitsu.loginAndRegistration.module.User;

public class UserRegistraionDao {
	public boolean registerUser(User user)  {
		//System.out.println("Running UserRegistrationDAO:: registerUser");

		String url ="jdbc:mysql://localhost:3306/test";
		String db_username="root";
		String db_password="Nisha@123";


		Connection con;
		PreparedStatement pstmt;

		String sql="insert into user values(?,?,?,?,?)";
		try {
			
			//Class.forName("com.mysql.cj.jbdc.Driver");
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,db_username,db_password);
			pstmt=con.prepareStatement(sql);

			pstmt.setInt(1, user.getId());
			pstmt.setString(2, user.getUserName());
			pstmt.setString(3, user.getPassword());
			pstmt.setInt(4, user.getPhone());
			pstmt.setString(5, user.getAddress());

			int result=pstmt.executeUpdate();

			if(result>0) 
				return true;


		} catch (Exception e) {

			e.printStackTrace();
		}
		System.out.println("Running UserRegistrationDAO:: registerUser");
		return false;
	}

}
